#ifndef KERNEL_H
#define KERNEL_H

#include "conv.h"
#include "matrix_ops.h"
#include "functional.h"
#include "linear.h"
#include "nn.h"

#endif // KERNEL_H